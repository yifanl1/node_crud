module.exports = {
    PORT : 4000,
    DB : 'mongodb://localhost:27017/node-crud',
}
